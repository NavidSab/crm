@extends('layouts.contentLayoutMaster')
 @section('title', $title)
@section('content')
<!-- Basic Tables start -->
<section id="multiple-column-form">
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">{{ $title }}</h4>
          </div>
          <div class="card-body">
            @if (count($errors) > 0)
            <div class="alert alert-danger">
              <strong>Whoops!</strong> There were some problems with your input.<br><br>
              <ul>
                 @foreach ($errors->all() as $error)
                   <li>{{ $error }}</li>
                 @endforeach
              </ul>
            </div>
          @endif
          <form class="form" action="{{ route('menu.store') }}" method="post">
              @csrf
              <div class="row">
                <div class="col-md-12 col-12">
                  <div class="mb-1">
                    <label class="form-label" for="first-name-column"> Name</label>
                    <input type="text" id="first-name-column" class="form-control" placeholder="Name" name="name" required>
                  </div>
                </div>
            </div> 
            <hr>
              <div class="row">
                <div class="col-12">
                   <a href="{{ route('menu') }}" class="btn btn-primary ">
                    <span class="align-middle d-sm-inline-block d-none">Back</span>
                  </a>
                  <button type="submit" class="btn btn-success ">Create</button>
                </div>
                </div>
              </form>
              </div>
          </div>
        </div>
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">Menu Items</h4>
          </div>
          <div class="card-body">
            @if (count($errors) > 0)
            <div class="alert alert-danger">
              <strong>Whoops!</strong> There were some problems with your input.<br><br>
              <ul>
                 @foreach ($errors->all() as $error)
                   <li>{{ $error }}</li>
                 @endforeach
              </ul>
            </div>
          @endif
          <form class="form" action="{{ route('menu.store') }}" method="post">
              @csrf
              <div class="row">
                <div class="col-md-3 col-12">
                  <div class="mb-1">
                    <label class="form-label" for="first-name-column"> Name</label>
                    <input type="text" id="first-name-column" class="form-control" placeholder="Name" name="name" required>
                  </div>
                </div>
                <div class="col-md-3 col-12">
                  <div class="mb-1">
                    <label class="form-label" for="first-name-column"> parent </label>
                    <select name="prent" class="select2 form-control">
                    <option value="">test</option>
                    <option value="">test</option>
                    <option value="">test</option>

                    </select>
                  </div>
                </div>
            </div> 
            <hr>
              <div class="row">
                <div class="col-6">
                  <button type="submit" class="btn btn-success ">Create</button>
                </div>
                </div>
              </form>
              </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<!-- Basic Tables end -->
@endsection
@section('page-script')
<script>
$('#select-all').click(function(event) {   
    if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
    } else {
        $(':checkbox').each(function() {
            this.checked = false;                       
        });
    }
});
</script>
@endsection
