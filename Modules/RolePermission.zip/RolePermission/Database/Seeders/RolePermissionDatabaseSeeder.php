<?php
namespace Modules\RolePermission\Database\Seeders;
use Illuminate\Database\Seeder;
use Modules\RolePermission\Entities\Permission;
use Modules\RolePermission\Entities\Role;
  class RolePermissionDatabaseSeeder extends Seeder
  {
      /**
       * Run the database seeds.
       *
       * @return void
       */
      public function run()
      {
        // Reset cached roles and permissions
        app()[\Modules\RolePermission\Services\PermissionRegistrar::class]->forgetCachedPermissions();
          $permissions = [
             'role-list',
             'role-create',
             'role-edit',
             'role-delete',
          ];
          foreach ($permissions as $permission) {
               Permission::create(['name' => $permission]);
          }
        $role = Role::create(['name' => 'super-admin']);
        $role->givePermissionTo(Permission::all());
      }
  }