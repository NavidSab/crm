<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Dashboard\\Providers\\DashboardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Dashboard\\Providers\\DashboardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);