<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);