<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Role\\Providers\\RoleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Role\\Providers\\RoleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);