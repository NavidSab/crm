<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FileManager\\Providers\\FileManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FileManager\\Providers\\FileManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);