<nav id="sidebar" class="active">
    <div class="sidebar-header">
        <img
            src="assets/img/bootstraper-logo.png"
            alt="bootraper logo"
            class="app-logo"></div>
        <ul class="list-unstyled components text-secondary">
            <li>
                <a href="<?php echo e(url('/')); ?>">
                    <i class="fas fa-home"></i>Home</a>
            </li>
            <li>
                <a href="<?php echo e(route('filemanager')); ?>">
                    <i class="fas fa-file-alt"></i>
                    FileManager</a>
            </li>
            <li>
                <a href="<?php echo e(route('user')); ?>">
                    <i class="fas fa-user"></i>
                    User</a>
            </li>
            <li>
                <a href="<?php echo e(route('rolepermission')); ?>">
                    <i class="fas fa-users"></i>
                    Role</a>
            </li>
            <li>
                <a href="<?php echo e(route('menu')); ?>">
                    <i class="fas fa-list"></i>
                    Menu</a>
            </li>
        </ul>
        <?php  $public_menu = Menu::getByName('king'); ?>
        <?php if($public_menu): ?>
        <ul class="list-unstyled components text-secondary">
            <?php $__currentLoopData = $public_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li >
                <a href="<?php echo e($menu['link']); ?>" title=""><?php echo e($menu['label']); ?></a>
                <?php if( $menu['child'] ): ?>
                <ul class="sub-menu">
                    <?php $__currentLoopData = $menu['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class=""><a href="<?php echo e($child['link']); ?>" title=""><?php echo e($child['label']); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
</nav>

 
    
<?php /**PATH /opt/lampp/htdocs/crm-main/Modules/Dashboard/Resources/views/include/sidebar.blade.php ENDPATH**/ ?>