<nav id="sidebar" class="active">
    <div class="sidebar-header">
        <img src="assets/img/bootstraper-logo.png" alt="bootraper logo" class="app-logo">
    </div>
    <ul class="list-unstyled components text-secondary">
        <li>
            <a href="<?php echo e(url('/')); ?>"><i class="fas fa-home"></i> Dashboard</a>
        </li>
         <li>
            <a href="<?php echo e(route('upload')); ?>"><i class="fas fa-file-alt"></i> Upload</a>
        </li>
        <li>
            <a href="<?php echo e(route('upload')); ?>"><i class="fas fa-file-alt"></i> Menu</a>
        </li>
        <li>
            <a href="<?php echo e(route('upload')); ?>"><i class="fas fa-file-alt"></i> Role</a>
        </li>
    </ul>
</nav><?php /**PATH /opt/lampp/htdocs/crm-king/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>