<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>
        This view is loaded from module: <?php echo config('RolePermission.name'); ?>

    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard::main.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/navidkinggraph/crm.navid.king.graphics/Modules/RolePermission/Resources/views/index.blade.php ENDPATH**/ ?>