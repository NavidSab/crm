<?php $__env->startSection('css'); ?>
<link href="<?php echo e(Module::asset('menu:menu.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <?php echo Menu::render(); ?>

<?php $__env->stopSection(); ?>  
<?php $__env->startSection('script'); ?>
<?php echo Menu::scripts(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard::main.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/crm-main/Modules/Menu/Resources/views/index.blade.php ENDPATH**/ ?>