<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
        <div class="page-title">
            <h3>Ulpad File
                                       <?php if(Session::has('message')): ?>
                            <div class="alert <?php echo e(Session::get('alert-class')); ?>">
                                <?php echo e(Session::get('message')); ?>

                            </div>
                <?php endif; ?> 
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addModal" ><i class="fas fa-plus-circle"></i> Add</button>
                <div class="modal fade" id="addModal" role="dialog" tabindex="-1">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Upload</h5>
                          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body text-start">
                          <p>Upload Your File Here</p>
                            <!-- Alert message (start) -->
                          <form accept-charset="utf-8" enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>
                              <div class="mb-3">
                                  <label for="file" class="form-label">File</label>
                                    <input type="hidden" id="user_id" value="<?php echo e(auth()->user()->id); ?>" >
                                  <input type="file" id="file_path" placeholder="File" class="form-control">
                                    <?php if($errors->has('file_path')): ?>
                                        <span class="errormsg text-danger"><?php echo e($errors->first('file_path')); ?></span>
                                    <?php endif; ?>
                              </div>
                              <div class="mb-3">
                                  <button  class="btn btn-primary" onsubmit="UploadManager.register(this,<?php echo e(route('upload.post')); ?>); return false;">submit</button>
                              </div>
                          </form>
                        </div>
                        <div class="modal-footer">
                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
            </h3>
        </div>
        <div class="box box-primary">
            <div class="box-body">
                <table width="100%" class="table table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th> Name</th>
                            <th>View</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(Module::asset('upload:js/app.js')); ?>">
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/crm-king/Modules/Upload/Resources/views/index.blade.php ENDPATH**/ ?>