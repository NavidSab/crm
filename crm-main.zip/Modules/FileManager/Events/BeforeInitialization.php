<?php

namespace Modules\FileManager\Events;

class BeforeInitialization
{
    /**
     * BeforeInitialization constructor.
     */
    public function __construct()
    {

    }
}
