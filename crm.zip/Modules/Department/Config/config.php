<?php

return [
    'name' => 'Department'
];
