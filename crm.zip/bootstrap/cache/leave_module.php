<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Leave\\Providers\\LeaveServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Leave\\Providers\\LeaveServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);