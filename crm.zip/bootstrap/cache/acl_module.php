<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Acl\\Providers\\AclServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Acl\\Providers\\AclServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);