<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Document\\Providers\\DocumentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Document\\Providers\\DocumentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);