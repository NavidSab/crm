<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\College\\Providers\\CollegeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\College\\Providers\\CollegeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);