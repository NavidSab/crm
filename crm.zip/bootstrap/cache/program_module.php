<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Program\\Providers\\ProgramServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Program\\Providers\\ProgramServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);